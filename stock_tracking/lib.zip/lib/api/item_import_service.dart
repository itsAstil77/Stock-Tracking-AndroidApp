import 'dart:convert';
import 'package:http/http.dart' as http;
import '../services/db_service.dart';
import '../models/item_model.dart';

class ItemImportService {
  static const String apiUrl = 'http://172.16.100.66:5041/api/Excel/ItemMasterSummary';

  static Future<bool> fetchAndSaveItems() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);

        for (var apiJson in data) {
          try {
            final item = ItemModel.fromApi(apiJson);
            await DBService.instance.insertItem(item);
          } catch (e) {
            print("Error inserting item: $e");
          }
        }
        return true;
      } else {
        print("API Error: ${response.statusCode}");
        return false;
      }
    } catch (e) {
      print("Error importing items: $e");
      return false;
    }
  }
}
