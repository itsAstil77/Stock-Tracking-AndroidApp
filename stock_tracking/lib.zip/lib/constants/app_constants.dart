import 'package:flutter/material.dart';

class AppConstants {
  static const String appName = 'Purple IQ';
  static const Color primaryColor = Color(0xFF6A1B9A); // Purple
}
