class StockCountModel {
  final int? id;
  final int itemId;
  final int count;
  final String lastUpdated;

  StockCountModel({
    this.id,
    required this.itemId,
    required this.count,
    required this.lastUpdated,
  });

  factory StockCountModel.fromMap(Map<String, dynamic> json) => StockCountModel(
        id: json['id'] as int?,
        itemId: json['item_id'] as int,
        count: json['count'] as int,
        lastUpdated: json['last_updated'] as String,
      );

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'item_id': itemId,
      'count': count,
      'last_updated': lastUpdated,
    };
  }
}
