class ItemModel {
  final String? id;
  final String name;
  final String description;
  final String barcode;
  final int count;
  final int apiId;
  final String qrCode;

  ItemModel(
      {this.id,
      required this.name,
      required this.description,
      required this.barcode,
      required this.count,
      required this.apiId,
      required this.qrCode});

  factory ItemModel.fromMap(Map<String, dynamic> map) {
    return ItemModel(
      id: map['id'],
      apiId: map['api_id'] ?? '',
      name: map['name'],
      description: map['description'] ?? '',
      qrCode: map['qr_code'],
      count: map['count'] ?? 0,
      barcode: map['Barcode'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'api_id': apiId,
      'name': name,
      'description': description,
      'qr_code': qrCode,
      'count': count,
    };
  }

  factory ItemModel.fromApi(Map<String, dynamic> json) {
    final fields = json['additionalFields'] ?? {};
    return ItemModel(
      apiId: json['id'] ?? '',
      name: fields['ItemCode'] ?? '',
      description: fields['Description'] ?? '',
      qrCode: json['barcode'] ?? '',
      count: int.tryParse(fields['Quantity'] ?? '0') ?? 0,
      barcode: json['Barcode'],
    );
  }
}
