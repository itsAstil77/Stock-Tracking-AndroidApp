import 'package:flutter/material.dart';
import 'package:stock_tracking/services/db_service.dart';
import '../../api/item_import_service.dart';

class ImportItemsScreen extends StatelessWidget {
  const ImportItemsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Import Items')),
      body: Center(
        child: ElevatedButton.icon(
          icon: const Icon(Icons.download),
          label: const Text("Import Item Master"),
          onPressed: () async {
            // Show loading indicator while importing
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => const Center(child: CircularProgressIndicator()),
            );

            final success = await ItemImportService.fetchAndSaveItems();

            // Close loading dialog
            Navigator.of(context).pop();

            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  success
                      ? "Items imported successfully!"
                      : "Failed to import items. Please try again.",
                ),
                backgroundColor: success ? Colors.green : Colors.red,
                duration: const Duration(seconds: 3),
              ),
            );

            DBService.instance.getItems();
          },
        ),
      ),
    );
  }
}
